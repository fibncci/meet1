会议室预定系统

功能
* 预订会议
* 查看自己预订的会议列表
* 编辑预订
* 上传会议资料
* 生成签到表
* 查看会议室预订日历
* 新增会议室
* 设置会议室维护计划
* 设置会议室设备
* 会议室设备类型管理
* 统计会议室使用情况
* 用户管理：添加、删除、编辑、注册

安装和运行

1 安装python
https://www.python.org/downloads/

2 安装依赖项
pip install -r requirements.txt

3 运行
python main.py

4 登录
http://localhost:5000

用户名：admin
密码：admin